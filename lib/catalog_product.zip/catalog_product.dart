import 'models/product.dart';

class CatalogProduct {
  static final items = [
    Product(
      id: 0,
      title: "เครื่องกรองน้ำ  Water Filter 5 steps",
      desc: "เครื่องดกรองน้ำดื่มแบบ FL-05 ปริมาณ 15 L/min สำหรับบ้านพักอาศํย",
      imageUrl: 'https://picsum.photos/250?image=9'
    ),
    Product(
      id: 1,
      title: "Robot: Smart Automation STEM",
      desc: "ชุดเรียนรู้ Smart Robot Automation kit for STEM Education ประกอบด้วย...",
      imageUrl: 'https://picsum.photos/250?image=9'
    ),
    Product(
      id: 2,
      title: "เครื่องกรองน้ำ  WF บ้านพักคอนโด",
      desc: "กรองน้ำแบบ 3 ท่อ 5 L/min สำหรับดื่ม",
      imageUrl: 'https://picsum.photos/250?image=9'
    ),
    Product(
      id: 3,
      title: "เครื่องกรองน้ำ  WF บ้านพักคอนโด",
      desc: "กรองน้ำแบบ 3 ท่อ 5 L/min สำหรับดื่ม",
      imageUrl: 'https://picsum.photos/250?image=9'
    ),
  ];
}